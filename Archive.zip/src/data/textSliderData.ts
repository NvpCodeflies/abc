type sliderDataType = {
  id: number;
  sliderText: string;
  ctaText: string;
  ctaLink: string;
}[];

const textSliderData: sliderDataType = [
  {
    id: 1,
    sliderText:
      'Remedy Cloud is your one stop shop in getting to know the latest news about the hottest cyber vulnerabilities',
    ctaText: 'call for action',
    ctaLink: '#',
  },
  {
    id: 2,
    sliderText:
      'Remedy Cloud is your one stop shop in getting to know the latest news about the hottest cyber vulnerabilities',
    ctaText: 'call for action',
    ctaLink: '#',
  },
  {
    id: 3,
    sliderText:
      'Remedy Cloud is your one stop shop in getting to know the latest news about the hottest cyber vulnerabilities',
    ctaText: 'call for action',
    ctaLink: '#',
  },
  {
    id: 4,
    sliderText:
      'Remedy Cloud is your one stop shop in getting to know the latest news about the hottest cyber vulnerabilities',
    ctaText: 'call for action',
    ctaLink: '#',
  },
];

export default textSliderData;
