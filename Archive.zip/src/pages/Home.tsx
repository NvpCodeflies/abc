import BlogsGrid from "../components/blogsGrid/BlogsGrid";
import SearchWrapper from "../components/searchWrapper/SearchWrapper";

export default function Home() {
  return (
    <>
    <SearchWrapper />
   <BlogsGrid />
    </>
  );
}
